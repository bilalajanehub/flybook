var API_KEY = 'Flight%20booker%201.2%20plus%20edition';
var URL = 'http://localhost:8000/api/API.php?API_KEY='+API_KEY;
//var URL_STATUS = 'http://localhost:8000/cgi-bin/status_check.cgi?';
var URL_STATUS = 'http://localhost:8000/cgi-bin/status_check?';