package dk.kea;

/**
 * Created by coag on 23-04-2018.
 */
public class MyUtil {
    private static final String API_KEY = "Flight%20booker%201.2%20plus%20edition";
    public static final String API_URL = "http://127.0.0.1:8000/api/API.php?API_KEY=" + API_KEY;
}
