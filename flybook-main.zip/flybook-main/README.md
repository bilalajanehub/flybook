# flybook

This is a (deliberately-vulnerable) application of a flight booking system. 

## Starting up the application

To build and run the Docker container, in the flybook project, you need to run:

	docker-compose build
  
	docker-compose up -d
  
## Accessing the web application

Go to:
* http://localhost:8000

* http://localhost:8000/book.html

* http://localhost:8000/service.html

